//
//  MyDetailKeyBoardView.h
//  LSKeyboard
//
//  Created by apple on 2018/8/1.
//  Copyright © 2018年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol MyDetailKeyBoardViewDelegate <NSObject>

-(void)enterDetailMessage:(NSString*)string;
-(void)deleteDetailMothed;
-(void)sureDetailMothed;
@end

@interface MyDetailKeyBoardView : UIView

-(void)show;

@property (nonatomic,weak)id <MyDetailKeyBoardViewDelegate> delegate;

@end
