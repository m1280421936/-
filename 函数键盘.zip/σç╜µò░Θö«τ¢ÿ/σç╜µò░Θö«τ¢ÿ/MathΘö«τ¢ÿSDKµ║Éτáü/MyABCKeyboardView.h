//
//  MyABCKeyboardView.h
//  LSKeyboard
//
//  Created by MyMac on 2018/7/30.
//  Copyright © 2018年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol MyABCKeyboardViewDelegate <NSObject>

@optional
-(void)enterABCMessage:(NSString*)string;
- (void)deleteButtonAction;
- (void)detailButtonAction;
- (void)sureButtonAction;


@end


@interface MyABCKeyboardView : UIView

//@property (nonatomic,assign)float bottomHeight;

@property (nonatomic,weak)id <MyABCKeyboardViewDelegate> delegate;

@end
