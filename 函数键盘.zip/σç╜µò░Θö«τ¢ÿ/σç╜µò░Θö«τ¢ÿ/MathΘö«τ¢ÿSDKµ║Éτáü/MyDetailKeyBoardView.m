//
//  MyDetailKeyBoardView.m
//  LSKeyboard
//
//  Created by apple on 2018/8/1.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "MyDetailKeyBoardView.h"
#import "UIButton+BackgroundColor.h"

#define Formula_W ([UIScreen mainScreen].bounds.size.width/7.5)
#define Number_W ([UIScreen mainScreen].bounds.size.width/5.77)
#define Color(a,b,c,d) [UIColor colorWithRed:a/255.0 green:b/255.0 blue:c/255.0 alpha:d]
#define ColorSame(a) [UIColor colorWithRed:a/255.0 green:a/255.0 blue:a/255.0 alpha:1]
#define View_H(a)  (a.bounds.size.height)
#define View_W(a)  (a.bounds.size.width)

#define MAXX(a) (CGRectGetMaxX(a.frame))
#define MAXY(a) (CGRectGetMaxY(a.frame))
#define Line(x,y,w,h) [[UIView alloc]initWithFrame:CGRectMake(x, y,w,h)]
#define IntToString(a) ([NSString stringWithFormat:@"%d",a])

#define X(a) (a.frame.origin.x)
#define Y(a) (a.frame.origin.y)

#define W ([UIScreen mainScreen].bounds.size.width)
#define H ([UIScreen mainScreen].bounds.size.height)

@interface MyDetailKeyBoardView ()

@property (nonatomic,strong)UIScrollView * scrollLeft;
@property (nonatomic,strong)UIScrollView * scrollRight;
@property (nonatomic,strong)UIView * bottomView;

@property (nonatomic,strong)NSMutableArray * buttonArray;
@property (nonatomic,strong)NSArray * buttonDataArray;

@property (nonatomic,strong)UIButton * objectLeftButton;
@property (nonatomic,strong)UIButton * clockButton;

@property (nonatomic,strong) NSTimer * timer;

@end
@implementation MyDetailKeyBoardView

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setUI];
    }
    return self;
}

-(void)show
{
    self.hidden = NO;
}

-(void)setUI
{
    [self addSubview:self.scrollLeft];
    [self setRight];
    [self addSubview:self.scrollRight];
    [self setLeft];
    [self addSubview:self.bottomView];
}

-(void)setLeft
{
    NSArray * arr = @[@"代数",@"几何",@"序号"];
    for (int i=0; i<3; i++) {
        UIButton * button = [UIButton new];
        button.tag = i;
        button.backgroundColor = self.scrollLeft.backgroundColor;
        [button setTitle:arr[i] forState:UIControlStateNormal];
        [button setTitleColor:ColorSame(101) forState:UIControlStateNormal];
        [button setTitleColor:ColorSame(50) forState:UIControlStateSelected];
        button.frame = CGRectMake(0,i*60,View_W(self.scrollLeft),60);
        [button addTarget:self action:@selector(leftClick:) forControlEvents:UIControlEventTouchUpInside];
        [button addObserver:self forKeyPath:@"selected" options:NSKeyValueObservingOptionNew context:nil];
        [self.scrollLeft addSubview:button];
        button.titleLabel.font = [UIFont systemFontOfSize:15];
        if(i==0)
           [self leftClick:button];
    }
    self.scrollLeft.contentSize = CGSizeMake(0, 3*60);
}
-(void)setRight
{
    int buttonWitdh = View_W(self.scrollRight)/5;
    int buttonHeight = 45;
    for (int i=0; i<25; i++) {
        UIButton * button = [UIButton new];
        button.tag = i;
        [button setTitleColor:ColorSame(50) forState:UIControlStateNormal];
        button.frame = CGRectMake((i%5)*buttonWitdh,(i/5)*buttonHeight,buttonWitdh,buttonHeight);
        button.titleLabel.font = [UIFont systemFontOfSize:20];
        [button addTarget:self action:@selector(rightClick:) forControlEvents:UIControlEventTouchUpInside];
        button.hidden = YES;
        button.layer.borderColor = ColorSame(225).CGColor;
        button.layer.borderWidth = 1.f;
        [self.scrollRight addSubview:button];
        [self.buttonArray addObject:button];
    }
}


#pragma mark -- Event Response

-(void)leftClick:(UIButton*)button
{
    button.selected = ! button.selected;
    self.objectLeftButton.selected = !self.objectLeftButton.selected;
    self.objectLeftButton = button;
    NSArray * arr = self.buttonDataArray[button.tag];
    self.scrollRight.contentSize = CGSizeMake(0,(arr.count/5+(arr.count%5>0?1:0))*45);
    for (int i=0; i<arr.count; i++) {
        NSDictionary * dic = (NSDictionary*)arr[i];
        UIButton * button = (UIButton*)self.buttonArray[i];
        [button setImage:[UIImage imageNamed:dic[@"name"]] forState:UIControlStateNormal];
        button.hidden = NO;
        button.code = dic[@"code"];
    }
    for (NSInteger i=arr.count;i<25; i++) {
        UIButton * button = (UIButton*)self.buttonArray[i];
        button.hidden = YES;
    }
}
-(void)rightClick:(UIButton*)button
{
    if ([self.delegate respondsToSelector:@selector(enterDetailMessage:)]) {
        [self.delegate enterDetailMessage:button.code];
        self.hidden = !self.clockButton.selected;
    }
}
-(void)deleteClick
{
    if ([self.delegate respondsToSelector:@selector(deleteDetailMothed)]) {
        [self.delegate deleteDetailMothed];
    }
}
-(void)backClick
{
    self.hidden = YES;
}
-(void)sureClick
{
    if ([self.delegate respondsToSelector:@selector(sureDetailMothed)]) {
        [self.delegate sureDetailMothed];
    }
}
-(void)clockClick:(UIButton*)button
{
    button.selected = !button.selected;
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    if ( [keyPath isEqualToString:@"selected"]) {
        UIButton * button = object;
        if (button.selected) {
            button.backgroundColor =ColorSame(255);
        }
        else
        {
            button.backgroundColor =self.scrollLeft.backgroundColor;
        }
    }
}
//自动删除方法
-(void)AutoDelete:(UILongPressGestureRecognizer*)longPress
{
    
    if (longPress.state == UIGestureRecognizerStateBegan) {
        //开始计时
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            self.timer = [NSTimer timerWithTimeInterval:0.05 target:self selector:@selector(deleteClick) userInfo:nil repeats:YES];
            [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
            [[NSRunLoop currentRunLoop] run];
            
        });
        
        
    }
    else if (longPress.state == UIGestureRecognizerStateChanged) {
        
    }
    else
    {
        [self.timer setFireDate:[NSDate distantFuture]];
    }
}
#pragma mark -- Get,Set

-(NSMutableArray*)buttonArray
{
    if (!_buttonArray) {
        _buttonArray = [NSMutableArray new];
    }
    return _buttonArray;
}

-(UIScrollView*)scrollLeft
{
    if (!_scrollLeft) {
        _scrollLeft = [[UIScrollView alloc]init];
        _scrollLeft.frame = CGRectMake(0, 0,70,View_H(self)-40);
        _scrollLeft.backgroundColor = Color(214, 217, 220, 1);
        _scrollLeft.alwaysBounceVertical = YES;
//        _scrollLeft.showsVerticalScrollIndicator = NO;
    }
    return _scrollLeft;
}
-(UIScrollView*)scrollRight
{
    if (!_scrollRight) {
        _scrollRight = [[UIScrollView alloc]init];
        _scrollRight.frame = CGRectMake(MAXX(_scrollLeft),0,View_W(self)-MAXX(_scrollLeft),View_H(_scrollLeft));
        _scrollRight.backgroundColor = ColorSame(245);
        _scrollRight.alwaysBounceVertical = YES;
        //        _scrollRight.showsVerticalScrollIndicator = NO;
    }
    return _scrollRight;
}
-(NSArray*)buttonDataArray
{
    if (!_buttonDataArray) {
        NSData *JSONData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"keyDetail" ofType:@"json"]];
         _buttonDataArray = [NSJSONSerialization JSONObjectWithData:JSONData options:NSJSONReadingAllowFragments error:nil];
        NSLog(@"%@",_buttonDataArray);
        NSArray * arr3 = @[@"①",@"②",@"③",@"④",@"⑤",
                           @"⑥",@"⑦",@"⑧",@"⑨",@"⑩",
                           @"(1)",@"(2)",@"(3)",@"(4)",@"(5)",
                           @"(6)",@"(7)",@"(8)",@"(9)",@"(10)"];
        
    }
    return _buttonDataArray;
}

-(UIView*)bottomView
{
    if (!_bottomView) {
        _bottomView = [[UIView alloc]initWithFrame:CGRectMake(0,View_H(self)-40,View_W(self), 40)];
        _bottomView.backgroundColor = ColorSame(229);
        _bottomView.layer.shadowColor =ColorSame(10).CGColor;
        _bottomView.layer.shadowOffset = CGSizeMake(0,0);
        _bottomView.layer.shadowOpacity = 0.4;//阴影透明度，默认0
        _bottomView.layer.shadowRadius = 3;//阴影半径，默认3
        
        UIButton * buttonback = [UIButton new];
        [buttonback setTitle:@"返回" forState:UIControlStateNormal];
        [buttonback setTitleColor:Color(95, 200, 153,1) forState:UIControlStateNormal];
        buttonback.titleLabel.font = [UIFont systemFontOfSize:15];
        [buttonback addTarget:self action:@selector(backClick) forControlEvents:UIControlEventTouchUpInside];
        buttonback.frame = CGRectMake(0, 0,70,View_H(_bottomView));
        [_bottomView addSubview:buttonback];
        
        UIButton * buttonSure = [UIButton new];
        [buttonSure setTitle:@"确定" forState:UIControlStateNormal];
        [buttonSure setTitleColor:ColorSame(101) forState:UIControlStateNormal];
        [buttonSure setTitleColor:Color(95, 200, 153,1) forState:UIControlStateSelected];
        buttonSure.titleLabel.font = [UIFont systemFontOfSize:15];
        [buttonSure addTarget:self action:@selector(sureClick) forControlEvents:UIControlEventTouchUpInside];
        buttonSure.frame = CGRectMake(View_W(_bottomView)-70, 0,70,View_H(_bottomView));
        [_bottomView addSubview:buttonSure];
        
        self.clockButton = [UIButton new];
        [self.clockButton setImage:[UIImage imageNamed:@"锁"] forState:UIControlStateNormal];
        [self.clockButton setImage:[UIImage imageNamed:@"锁1"] forState:UIControlStateSelected];
        [self.clockButton addTarget:self action:@selector(clockClick:) forControlEvents:UIControlEventTouchUpInside];
        self.clockButton.frame = CGRectMake(0, 0,View_H(_bottomView),View_H(_bottomView));
        self.clockButton.center = CGPointMake((W/2-70)/2+70, View_H(_bottomView)/2);
        [_bottomView addSubview:self.clockButton];
        
        UIButton * buttonDelete = [UIButton new];
        [buttonDelete addTarget:self action:@selector(deleteClick) forControlEvents:UIControlEventTouchUpInside];
        [buttonDelete setImage:[UIImage imageNamed:@"退格"] forState:UIControlStateNormal];
        buttonDelete.frame = CGRectMake(View_W(_bottomView)-70, 0,70,View_H(_bottomView));
        buttonDelete.center = CGPointMake((W/2-70)/2+W/2, View_H(_bottomView)/2);
        [_bottomView addSubview:buttonDelete];
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(AutoDelete:)];
        longPress.minimumPressDuration = 2; //定义按的时间
        [buttonDelete addGestureRecognizer:longPress];
    }
    return _bottomView;
}

@end
