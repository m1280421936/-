//
//  MathKeyBoard.m
//  LSKeyboard
//
//  Created by apple on 2018/7/31.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "MathKeyBoard.h"
#import "MyWebKeyboard.h"
#import "MyKeyBoardView.h"

#define MAXX(a) (CGRectGetMaxX(a.frame))
#define MAXY(a) (CGRectGetMaxY(a.frame))
#define X(a) (a.frame.origin.x)
#define Y(a) (a.frame.origin.y)

#define Color(a,b,c,d) [UIColor colorWithRed:a/255.0 green:b/255.0 blue:c/255.0 alpha:d]
#define View_H(a)  (a.bounds.size.height)
#define View_W(a)  (a.bounds.size.width)
#define W ([UIScreen mainScreen].bounds.size.width)
#define H ([UIScreen mainScreen].bounds.size.height)

@interface MathKeyBoard ()<MyKeyBoardViewDelegate,MyWebKeyboardDelegate>

@property (nonatomic, strong) MyWebKeyboard * myKeyInputBox;
@property (nonatomic,strong) MyKeyBoardView * keyBoardView;

@property (nonatomic,assign) BOOL isShowFirst;

@property (nonatomic,assign) int isWidth;
@property (nonatomic,assign) int isHeight;

@end

@implementation MathKeyBoard

-(instancetype)init
{
    if (self = [super init]) {
        [self setUI];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setUI];
    }
    return self;
}

-(void)setUI
{
    self.isShowFirst = YES;
    [self addSubview:self.myKeyInputBox];
    [self addSubview:self.keyBoardView];
    self.frame = CGRectMake(X(self), Y(self), View_W(self), MAXY(self.keyBoardView));
}

-(void)showKey:(BOOL)isBool
{
    self.isShowFirst = NO;
    __weak typeof(self) weakSelf = self;
    if (isBool) {
        //show
        [UIView animateWithDuration:0.25 animations:^{
            weakSelf.center = CGPointMake(W/2,H-View_H(self)/2);
        } completion:^(BOOL finished) {
            
        }];
    }
    else
    {
        //close
        [UIView animateWithDuration:0.25 animations:^{
            weakSelf.center = CGPointMake(W/2,H+View_H(self)/2);
        } completion:^(BOOL finished) {
            
        }];
    }
}

#pragma mark -- Delegate
-(void)enterMessage:(NSString *)string
{
    NSString *jsStr = [NSString stringWithFormat:@"writeField('%@')",string];
    [self.myKeyInputBox stringByEvaluatingJavaScriptFromString:jsStr];
}
- (void)deleteButtonAction
{
    NSString *jsStr = [NSString stringWithFormat:@"textField.keystroke(\"Backspace\")"];
    [self.myKeyInputBox stringByEvaluatingJavaScriptFromString:jsStr];
}
-(void)enterMothed:(NSString *)string
{
    NSString *jsStr = [NSString stringWithFormat:@"textField.keystroke(\"%@\")",string];
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(),^{
        [weakSelf.myKeyInputBox stringByEvaluatingJavaScriptFromString:jsStr];
    });
}
-(void)sureMothed
{
    //请执行确定事件
    NSLog(@"请执行确定事件");
    
    NSString * string =  [self.myKeyInputBox stringByEvaluatingJavaScriptFromString:@"getLatex()"];
    NSLog(@"输入框打印：%@",string);
}
-(void)updateWebHeight:(int)height andWidth:(int)width
{
    __block typeof(height) blockHeight = height;
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(),^
    {
        if (weakSelf.isShowFirst) {
            return;
        }
        blockHeight = (blockHeight<50?50:blockHeight+10);
        if (blockHeight>200||width>W) {
            weakSelf.myKeyInputBox.scrollView.scrollEnabled = YES;
//            CGFloat keyW = weakSelf.myKeyInputBox.scrollView.contentOffset.x;
//            CGFloat keyH = weakSelf.myKeyInputBox.scrollView.contentOffset.y;
//
//            if (height!=weakSelf.isHeight) {
//                keyH = height;
//                keyH = keyH-View_H(weakSelf.myKeyInputBox);
//            }
//            if (width!=weakSelf.isWidth) {
//                keyW = width;
//            }
            //
            weakSelf.myKeyInputBox.scrollView.contentSize = CGSizeMake(width>W?width+10:W-10*2, blockHeight);
//            weakSelf.myKeyInputBox.scrollView.contentOffset = CGPointMake(keyW-View_W(self.myKeyInputBox),keyH);
//            weakSelf.isWidth =  width;
//            weakSelf.isHeight = height;
            if (height>200) {
                return;
            }
            
        }
        else
        {
            weakSelf.myKeyInputBox.scrollView.scrollEnabled = NO;
        }
//        weakSelf.isWidth =  width;
//        weakSelf.isHeight = height;
        weakSelf.myKeyInputBox.frame =CGRectMake(10,7,W-10*2,blockHeight);
        weakSelf.keyBoardView.center = CGPointMake(weakSelf.keyBoardView.center.x,MAXY(weakSelf.myKeyInputBox)+7+View_H(weakSelf.keyBoardView)/2);
        weakSelf.frame = CGRectMake(X(weakSelf),H-MAXY(weakSelf.keyBoardView), View_W(weakSelf), MAXY(weakSelf.keyBoardView));
    });
    
}
#pragma mark -- Get,Set
-(MyWebKeyboard*)myKeyInputBox
{
    if (!_myKeyInputBox) {
        //246
        _myKeyInputBox = [[MyWebKeyboard alloc]initWithFrame:CGRectMake(10,7,W-10*2,50)];
        self.isWidth =  W-10*2;
        self.isHeight = 40;
        _myKeyInputBox.layer.borderColor = Color(25,152,236,1).CGColor;
        _myKeyInputBox.layer.borderWidth = 1.f;
        _myKeyInputBox.backgroundColor = [UIColor whiteColor];
        //_myKeyInputBox.scrollView.showsHorizontalScrollIndicator = NO;
        _myKeyInputBox.mydelegate = self;
    }
    return _myKeyInputBox;
}
-(MyKeyBoardView*)keyBoardView
{
    if (!_keyBoardView) {
        _keyBoardView = [MyKeyBoardView new];
        _keyBoardView.delegate =self;
        _keyBoardView.frame = CGRectMake(0,MAXY(self.myKeyInputBox)+7,W,W/1.45);
        _keyBoardView.backgroundColor = Color(214, 217, 220, 1);
        [_keyBoardView setUI];
    }
    return _keyBoardView;
}

@end

