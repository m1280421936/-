//
//  MyKeyBoardView.m
//  LSKeyboard
//
//  Created by apple on 2018/7/28.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "MyKeyBoardView.h"
#import "UIButton+BackgroundColor.h"
#import "UITextField+Cursor.h"
#import "MyABCKeyboardView.h"
#import "MyDetailKeyBoardView.h"

#define Formula_W ([UIScreen mainScreen].bounds.size.width/7.5)
#define Number_W ([UIScreen mainScreen].bounds.size.width/5.77)
#define Color(a,b,c,d) [UIColor colorWithRed:a/255.0 green:b/255.0 blue:c/255.0 alpha:d]
#define ColorSame(a) [UIColor colorWithRed:a/255.0 green:a/255.0 blue:a/255.0 alpha:1]
#define View_H(a)  (a.bounds.size.height)
#define View_W(a)  (a.bounds.size.width)

#define MAXX(a) (CGRectGetMaxX(a.frame))
#define MAXY(a) (CGRectGetMaxY(a.frame))
#define Line(x,y,w,h) [[UIView alloc]initWithFrame:CGRectMake(x, y,w,h)]
#define IntToString(a) ([NSString stringWithFormat:@"%d",a])

#define X(a) (a.frame.origin.x)
#define Y(a) (a.frame.origin.y)

#define W ([UIScreen mainScreen].bounds.size.width)
#define H ([UIScreen mainScreen].bounds.size.height)

@interface MyKeyBoardView ()<MyABCKeyboardViewDelegate,MyDetailKeyBoardViewDelegate>

@property (nonatomic,strong) UIView * view_left_one;
@property (nonatomic,strong) UIView * view_left_two;
@property (nonatomic,strong) UIView * view_right_one;
@property (nonatomic,strong) NSArray * arrayData;

@property (nonatomic,strong) UIButton * buttonSure;

@property (nonatomic, strong) MyDetailKeyBoardView * myDetailKeyBoardView;
//@property (nonatomic, strong) MyABCKeyboardView * myABCKeyboardView;

@property (nonatomic,strong) NSTimer * timer;

@end

@implementation MyKeyBoardView

-(instancetype)init
{
    if (self = [super init]) {
        //[self setUI];
    }
    return self;
}

-(void)setUI
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateButton:) name:@"MYKEYBOARDSUREBUTTON" object:nil];
    
    NSArray * arr_1 = @[@"x",@"y",@"a",@"b"];
    NSArray * arr_2 = @[@"分号整",@"二次幂",@"N次幂",@"根号"];
    
    [self addSubview:self.view_left_one];
    [self addSubview:self.view_left_two];
    
    //创建左侧两个竖着的View
    for (int i=0; i<arr_1.count; i++) {
        [self setButtonForFormula:i andNum:arr_1.count andText:arr_1[i] andSuperView:_view_left_one andImage:NO];
        [self setButtonForFormula:i andNum:arr_2.count andText:arr_2[i] andSuperView:_view_left_two andImage:YES];
    }
    
    UIView * labstNumber = [self createNumberView:_view_left_two];
    [self createRightButton:W-MAXX(labstNumber)];
    [self createBottomView];
    [self addSubview:self.myDetailKeyBoardView];
}
-(void)updateButton:(NSNotification *)notification
{
    NSDictionary *userInfo = notification.userInfo;
    NSString * isSelect = userInfo[@"isSelect"];
    if (isSelect.length>0) {
        self.buttonSure.selected = YES;
    }
    else
    {
        self.buttonSure.selected = NO;
    }
}
    
    
#pragma mark -- Delegate
- (void)detailButtonAction
{
    //符字的点击事件
    //跳转到”符“的键盘
    [self.myDetailKeyBoardView show];
}
- (void)sureButtonAction
{
    //确定点击事件
    if ([self.delegate respondsToSelector:@selector(sureMothed)]) {
        [self.delegate sureMothed];
    }
}
- (void)deleteButtonAction
{
    if ([self.delegate respondsToSelector:@selector(enterMothed:)])
    {
        [self.delegate enterMothed:self.arrayData[4]];
    }
}
-(void)enterABCMessage:(NSString*)string
{
    if ([self.delegate respondsToSelector:@selector(enterMessage:)]) {
        [self.delegate enterMessage:string];
    }
}

-(void)enterDetailMessage:(NSString*)string
{
    if ([self.delegate respondsToSelector:@selector(enterMessage:)]) {
        [self.delegate enterMessage:string];
    }
}
-(void)deleteDetailMothed
{
    if ([self.delegate respondsToSelector:@selector(enterMothed:)])
    {
        [self.delegate enterMothed:self.arrayData[4]];
    }
}
-(void)sureDetailMothed
{
    //确定点击事件
    if ([self.delegate respondsToSelector:@selector(sureMothed)]) {
        [self.delegate sureMothed];
    }
}

#pragma mark -- Event Response
//按钮点击通用方法
-(void)buttonChar:(UIButton*)button
{
    if (button.titleLabel.text==NULL) {
        NSLog(@"点击的是：%ld",button.tag);
        if (button.tag==4) {
            if ([self.delegate respondsToSelector:@selector(enterMothed:)]) {
                //自动(回退/删除)方法
                [self.delegate enterMothed:self.arrayData[button.tag]];
            }
            return;
        }
        if ([self.delegate respondsToSelector:@selector(enterMessage:)]) {
            [self.delegate enterMessage:self.arrayData[button.tag]];
        }
    }
    else
    {
        NSLog(@"点击的是：%@",button.titleLabel.text);
        if ([button.titleLabel.text isEqualToString:@"(  )"]) {
            if ([self.delegate respondsToSelector:@selector(enterMessage:)]) {
                [self.delegate enterMessage:@"\\\\left(  \\\\right)"];
            }
            return;
        }
        if ([button.titleLabel.text isEqualToString:@"ABC"]) {
            MyABCKeyboardView * myABCKeyboardView = [[MyABCKeyboardView alloc]initWithFrame:CGRectMake(0, 0,View_W(self),View_H(self))];
            myABCKeyboardView.delegate = self;
            myABCKeyboardView.backgroundColor = self.backgroundColor;
            [self addSubview:myABCKeyboardView];
            return;
        }
        else if ([button.titleLabel.text isEqualToString:@"符"])
        {
            //跳转到”符“的键盘
            [self.myDetailKeyBoardView show];
        }
        else if ([button.titleLabel.text isEqualToString:@"确定"])
        {
            if (button.selected) {
                //确定点击事件
                if ([self.delegate respondsToSelector:@selector(sureMothed)]) {
                    [self.delegate sureMothed];
                }
            }
            else
            {
                NSLog(@"确定键不允许点击");
            }
        }
        else    if ([self.delegate respondsToSelector:@selector(enterMessage:)]) {
            [self.delegate enterMessage:button.titleLabel.text];
        }
        
    }
}

//自动删除方法
-(void)AutoDelete:(UILongPressGestureRecognizer*)longPress
{
    
    if (longPress.state == UIGestureRecognizerStateBegan) {
        //开始计时
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            self.timer = [NSTimer timerWithTimeInterval:0.05 target:self selector:@selector(deleteIng) userInfo:nil repeats:YES];
            [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
            [[NSRunLoop currentRunLoop] run];
            
        });
        
        
    }
    else if (longPress.state == UIGestureRecognizerStateChanged) {
        
    }
    else
    {
        [self.timer setFireDate:[NSDate distantFuture]];
    }
}

//删除键方法
-(void)deleteIng
{
    if ([self.delegate respondsToSelector:@selector(enterMothed:)])
    {
        [self.delegate enterMothed:self.arrayData[4]];
    }
}

//NO Highed
-(void)noHighed:(UIButton*)button
{
    button.highlighted = NO;
}

#pragma mark -- SetUI
//中间键盘
-(UIView*)createNumberView:(UIView*)view
{
    UIButton * lastButton;
    //创建数字按钮
    for (int i=0; i<11; i++) {
        
        UIButton * button = [UIButton new];
        [button setTitle:IntToString(i+1) forState:UIControlStateNormal];
        [button setBackgroundColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setBackgroundColor:Color(172,173,177,1) forState:UIControlStateHighlighted];
        button.titleLabel.font = [UIFont systemFontOfSize:20];
        button.layer.cornerRadius = 5.f;
        button.layer.shadowColor =ColorSame(10).CGColor;
        button.layer.shadowOffset = CGSizeMake(0,0);
        button.layer.shadowOpacity = 0.4;//阴影透明度，默认0
        button.layer.shadowRadius = 1;//阴影半径，默认3
        [button setTitleColor:ColorSame(10) forState:UIControlStateNormal];
        [button addTarget:self action:@selector(buttonChar:) forControlEvents:UIControlEventTouchUpInside];
        int buttonH = Formula_W-4;
        if (i<9) {
            button.frame = CGRectMake(MAXX(view)+5+(i%3)*(Number_W+5),(i/3)*(buttonH+5)+5,Number_W,buttonH);
        }
        else if(i==9)
        {
            button.frame = CGRectMake(MAXX(view)+5,(i/3)*(buttonH+5)+5,Number_W*2+5,buttonH);
            [button setTitle:IntToString(0) forState:UIControlStateNormal];
        }
        else
        {
            button.frame = CGRectMake(MAXX(view)+5+2*Number_W+5+5,(i/3)*(buttonH+5)+5,Number_W,buttonH);
            [button setTitle:@"." forState:UIControlStateNormal];
        }
        [self addSubview:button];
        lastButton = button;
    }
    return lastButton;
}
//右侧功能区
-(void)createRightButton:(int)lessW
{
    NSArray * arr = @[@"退格",@"+",@"-",@"="];
    for (int i=0; i<4; i++) {
        UIButton * button = [UIButton new];
        button.frame = CGRectMake(W-lessW+5, 5+i*(Formula_W-4+5),lessW-10, Formula_W-4);
        if (i==0) {
            [button setImage:[UIImage imageNamed:arr[i]] forState:UIControlStateNormal];
            UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(AutoDelete:)];
            longPress.minimumPressDuration = 2; //定义按的时间
            [button addGestureRecognizer:longPress];
        }
        else
        {
            [button setTitle:arr[i] forState:UIControlStateNormal];
            [button setTitleColor:ColorSame(10) forState:UIControlStateNormal];
        }
        [button setBackgroundColor:Color(189, 190, 195,1) forState:UIControlStateNormal];
        [button setBackgroundColor:Color(172,173,177,1) forState:UIControlStateHighlighted];
        button.titleLabel.font = [UIFont systemFontOfSize:20];
        button.layer.cornerRadius = 5.f;
        button.layer.shadowColor =ColorSame(10).CGColor;
        button.layer.shadowOffset = CGSizeMake(0,0);
        button.layer.shadowOpacity = 0.4;//阴影透明度，默认0
        button.layer.shadowRadius = 1;//阴影半径，默认3
        button.tag = i+4;
        [button addTarget:self action:@selector(buttonChar:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
    }
}
//底部功能区
-(void)createBottomView
{
    NSArray * arr_1 = @[@"ABC",@"符"];
    UIButton * lastButton;
    for (int i=0; i<2; i++) {
        UIButton * button = [UIButton new];
        button.frame = CGRectMake(5+i*(Formula_W+2+5),MAXY(_view_left_one)+5, Formula_W+2,View_H(self)-MAXY(_view_left_one)-10);
        [button setTitle:arr_1[i] forState:UIControlStateNormal];
        [button setTitleColor:ColorSame(10) forState:UIControlStateNormal];
        [button setBackgroundColor:Color(189, 190, 195,1) forState:UIControlStateNormal];
        [button setBackgroundColor:Color(172,173,177,1) forState:UIControlStateHighlighted];
        button.titleLabel.font = [UIFont systemFontOfSize:15];
        button.layer.cornerRadius = 5.f;
        [button addTarget:self action:@selector(buttonChar:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
        lastButton = button;
    }
    
    UIView * view = [UIView new];
    view.frame = CGRectMake(5+MAXX(lastButton),Y(lastButton),(View_W(lastButton)-6)*4,View_H(lastButton));
    view.backgroundColor = Color(189, 190, 195, 1);
    view.layer.cornerRadius = 5.f;
    view.clipsToBounds = YES;
    NSArray * arr_2 = @[@"<",@">",@"(  )",@","];
    [self addSubview:view];
    for (int i=0; i<4; i++) {
        UIButton * button = [UIButton new];
        button.frame = CGRectMake(i*View_W(view)/4,0,View_W(view)/4,View_H(view));
        [button setTitle:arr_2[i] forState:UIControlStateNormal];
        [button setTitleColor:ColorSame(10) forState:UIControlStateNormal];
        [button setBackgroundColor:Color(189, 190, 195,1) forState:UIControlStateNormal];
        [button setBackgroundColor:Color(172,173,177,1) forState:UIControlStateHighlighted];
        button.titleLabel.font = [UIFont systemFontOfSize:20];
        [button addTarget:self action:@selector(buttonChar:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:button];
        if(i>0)
        {
            UIView * line = Line(X(button),5,1,View_H(button)-10);
            line.backgroundColor = Color(150, 151, 156, 1);
            [view addSubview:line];
        }
    }
    
    UIButton * buttonSure = [UIButton new];
    buttonSure.frame = CGRectMake(MAXX(view)+5,Y(view),View_W(self)-MAXX(view)-10,View_H(view));
    [buttonSure setTitle:@"确定" forState:UIControlStateNormal];
    self.buttonSure = buttonSure;
    [buttonSure setBackgroundColor:Color(201,204,207,1) forState:UIControlStateNormal];
    [buttonSure setTitleColor:Color(138, 140, 142, 1) forState:UIControlStateNormal];
    [buttonSure setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    buttonSure.titleLabel.font = [UIFont systemFontOfSize:15];
    buttonSure.layer.cornerRadius = 5.f;
    [buttonSure addTarget:self action:@selector(noHighed:) forControlEvents:UIControlEventAllTouchEvents];
    [buttonSure addTarget:self action:@selector(buttonChar:) forControlEvents:UIControlEventTouchUpInside];
    [buttonSure addObserver:self forKeyPath:@"selected" options:NSKeyValueObservingOptionNew context:nil];
    [self addSubview:buttonSure];
    
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    if ( [keyPath isEqualToString:@"selected"]) {
        UIButton * button = object;
        if (button.selected) {
            button.backgroundColor =Color(95, 200, 153,1);
        }
        else
        {
            button.backgroundColor =Color(201,204,207,1);
        }
    }
}
//左侧功能区按钮通用创建方法
-(void)setButtonForFormula:(int)i andNum:(NSInteger)num andText:(NSString*)text andSuperView:(UIView*)view andImage:(BOOL)isImage
{
    UIButton * button = [UIButton new];
    button.frame = CGRectMake(0,i*View_H(view)/num,Formula_W,View_H(view)/num);
    [button setBackgroundColor:[UIColor clearColor] forState:UIControlStateNormal];
    [button setBackgroundColor:Color(0, 0, 0, 0.1) forState:UIControlStateHighlighted];
    [button addTarget:self action:@selector(buttonChar:) forControlEvents:UIControlEventTouchUpInside];
    
    if (isImage) {
        [button setBackgroundImage:[UIImage imageNamed:text] forState:UIControlStateNormal];
    }
    else
    {
        [button setTitleColor:ColorSame(10) forState:UIControlStateNormal];
        [button setTitle:text forState:UIControlStateNormal];
    }
    button.tag = i;
    [view addSubview:button];
    
    if (i>0) {
        UIView * line = Line(5,button.frame.origin.y,View_W(button)-10,1);
        line.backgroundColor = Color(150, 151, 156, 1);
        [view addSubview:line];
    }
}

#pragma mark -- Get,Set

-(UIView*)view_left_one
{
    if (!_view_left_one) {
        _view_left_one = [UIView new];
        _view_left_one.frame = CGRectMake(5, 5,Formula_W,Formula_W*4);
        _view_left_one.backgroundColor = Color(189, 190, 195, 1);
        _view_left_one.layer.cornerRadius = 5.f;
        _view_left_one.clipsToBounds = YES;
    }
    return _view_left_one;
}

-(UIView*)view_left_two
{
    if (!_view_left_two) {
        _view_left_two = [UIView new];
        _view_left_two.frame = CGRectMake(5+MAXX(self.view_left_one), 5,Formula_W,Formula_W*4);
        _view_left_two.backgroundColor = Color(189, 190, 195, 1);
        _view_left_two.layer.cornerRadius = 5.f;
        _view_left_two.clipsToBounds = YES;
    }
    return _view_left_two;
}

-(MyDetailKeyBoardView*)myDetailKeyBoardView
{
    if (!_myDetailKeyBoardView) {
        _myDetailKeyBoardView = [[MyDetailKeyBoardView alloc]initWithFrame:CGRectMake(0, 0, View_W(self), View_H(self))];
        _myDetailKeyBoardView.hidden = YES;
        _myDetailKeyBoardView.delegate = self;
        _myDetailKeyBoardView.backgroundColor = self.backgroundColor;
    }
    return _myDetailKeyBoardView;
}

-(NSArray *)arrayData
{
    if (!_arrayData) {
        //_arrayData = [NSArray new];
        _arrayData = @[@"\\\\frac {}{}",@"^2",@"^{}",@"\\\\sqrt {}",@"Backspace",@"\\\\sqrt {}"];
    }
    return _arrayData;
}
@end
