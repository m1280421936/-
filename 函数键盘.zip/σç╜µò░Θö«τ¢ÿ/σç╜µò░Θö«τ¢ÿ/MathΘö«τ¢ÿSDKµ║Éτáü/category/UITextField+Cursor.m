//
//  UITextField+Cursor.m
//  LSKeyboard
//
//  Created by apple on 2018/7/27.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "UITextField+Cursor.h"
#import <objc/runtime.h>


static NSString *adjust = @"adjust";
@implementation UITextField (Cursor)

-(void)setCursor:(CGFloat)cursor{
    objc_setAssociatedObject(self, &adjust, @(cursor), OBJC_ASSOCIATION_ASSIGN);
    UILabel * leftView = [[UILabel alloc] initWithFrame:CGRectMake(cursor,0,cursor,self.frame.size.height)];
    leftView.backgroundColor = [UIColor clearColor];
    self.leftView = leftView;
    self.leftViewMode = UITextFieldViewModeAlways;
}
-(CGFloat)cursor{
    id  value = objc_getAssociatedObject(self, &adjust);
    return  [value floatValue ];
}


@end
