//
//  UIButton+BackgroundColor.m
//  LSKeyboard
//
//  Created by apple on 2018/7/27.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "UIButton+BackgroundColor.h"
#import <objc/runtime.h>
@interface UIButton ()

@property (nonatomic,strong)NSMutableDictionary * dicBorderColorState;

@end

@implementation UIButton (BackgroundColor)
-(void)setBackgroundColor:(UIColor*)color forState:(UIControlState)state
{
    if (!self.dicBorderColorState) {
        self.dicBorderColorState = [[NSMutableDictionary alloc]init];
    }
    if(state == UIControlStateNormal)
    {
        self.backgroundColor = color;
        [self.dicBorderColorState setObject:color forKey:@"UIControlStateNormal"];
    }
    else if(state == UIControlStateSelected)
    {
        [self.dicBorderColorState setObject:color forKey:@"UIControlStateSelected"];
    }
    else if(state == UIControlStateHighlighted)
    {
        [self.dicBorderColorState setObject:color forKey:@"UIControlStateHighlighted"];
    }
}

-(void)setHighlighted:(BOOL)highlighted
{
    [super setHighlighted:highlighted];
    if (highlighted&&self.dicBorderColorState[@"UIControlStateHighlighted"]) {
        self.backgroundColor = self.dicBorderColorState[@"UIControlStateHighlighted"];
    }
    else if(self.dicBorderColorState[@"UIControlStateNormal"])
    {
        if (!self.selected) {
            self.backgroundColor = self.dicBorderColorState[@"UIControlStateNormal"];
        }
    }
}

//-(void)setSelected:(BOOL)selected
//{
//    [super setSelected:selected];
//
//}
static char isDicBorderColorStateKey;
-(NSMutableDictionary*)dicBorderColorState
{
    return objc_getAssociatedObject(self, &isDicBorderColorStateKey);
}
-(void)setDicBorderColorState:(NSMutableDictionary *)dicBorderColorState
{
    objc_setAssociatedObject(self, &isDicBorderColorStateKey, dicBorderColorState, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

static char isCodeKey;
-(NSString*)code
{
    return objc_getAssociatedObject(self, &isCodeKey);
}
-(void)setCode:(NSString *)code
{
    objc_setAssociatedObject(self, &isCodeKey, code, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

@end
