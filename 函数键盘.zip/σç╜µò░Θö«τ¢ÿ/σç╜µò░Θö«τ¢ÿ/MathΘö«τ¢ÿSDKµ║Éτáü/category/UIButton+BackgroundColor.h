//
//  UIButton+BackgroundColor.h
//  LSKeyboard
//
//  Created by apple on 2018/7/27.
//  Copyright © 2018年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (BackgroundColor)



-(void)setBackgroundColor:(UIColor*)color forState:(UIControlState)state;

@property (nonatomic,copy)NSString * code;

@end
