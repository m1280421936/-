//
//  MyWebKeyboard.m
//  LSKeyboard
//
//  Created by apple on 2018/7/28.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "MyWebKeyboard.h"
#import "MyKeyBoardView.h"


#define View_H(a)  (a.bounds.size.height)
#define View_W(a)  (a.bounds.size.width)
#define W ([UIScreen mainScreen].bounds.size.width)
#define H ([UIScreen mainScreen].bounds.size.height)
#define Color(a,b,c,d) [UIColor colorWithRed:a/255.0 green:b/255.0 blue:c/255.0 alpha:d]
#define ColorSame(a) [UIColor colorWithRed:a/255.0 green:a/255.0 blue:a/255.0 alpha:1]


@interface MyWebKeyboard ()<UIGestureRecognizerDelegate>

@end

@implementation MyWebKeyboard


-(instancetype)init
{
    if (self = [super init]) {
        [self setUI];
        
        
    }
    return self;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setUI];
    }
    return self;
}
-(void)setUI
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapToDo)];
    tap.delegate = self;
    tap.numberOfTapsRequired = 1;
    //tap.numberOfTouchesRequired = 1;
    [self addGestureRecognizer:tap];
    self.scrollView.scrollEnabled = NO;
    NSURL *filePath =[[NSBundle mainBundle] URLForResource:@"index.html" withExtension:nil];
    [self loadRequest:[NSURLRequest requestWithURL:filePath]];
    
    self.context = [self valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    // 打印异常
    self.context.exceptionHandler =
    ^(JSContext *context, JSValue *exceptionValue)
    {
        context.exception = exceptionValue;
        NSLog(@"%@", exceptionValue);
    };
    self.context[@"TongyiEduBridge"] = self;
}

- (void)mathFieldHeightChange:(NSString*)height andWidth:(NSString *)width
{
    NSLog(@"返回的高度：%@",width);
    NSLog(@"返回的宽度：%@",height);
    dispatch_async(dispatch_get_main_queue(),^{
        NSString * string =  [self stringByEvaluatingJavaScriptFromString:@"getLatex()"];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"MYKEYBOARDSUREBUTTON" object:nil userInfo:@{@"isSelect":string}];
    });
    
    
    
    if ([self.mydelegate respondsToSelector:@selector(updateWebHeight:andWidth:)]) {
        [self.mydelegate updateWebHeight:[width intValue] andWidth:[height intValue]];
    }
    
}
-(void)singleTapToDo
{
    
}
- (void)done{
    [self resignFirstResponder];
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender{
    return NO;
}




@end
