//
//  MyWebKeyboard.h
//  LSKeyboard
//
//  Created by apple on 2018/7/28.
//  Copyright © 2018年 apple. All rights reserved.
//

#import <WebKit/WebKit.h>
#import <JavaScriptCore/JavaScriptCore.h>

@protocol MyWebKeyboardJSExport <JSExport>

@optional

JSExportAs
(mathFieldHeightChange  /** 作为js方法的别名 */,
 - (void)mathFieldHeightChange:(NSString*)height andWidth:(NSString*)width
 );
@end
@protocol MyWebKeyboardDelegate <NSObject>

-(void)updateWebHeight:(int)height andWidth:(int)width;

@end

@interface MyWebKeyboard : UIWebView<UIWebViewDelegate,MyWebKeyboardJSExport>

@property (nonatomic ,strong) JSContext *context;

@property (nonatomic ,weak) id <MyWebKeyboardDelegate> mydelegate;

@end
