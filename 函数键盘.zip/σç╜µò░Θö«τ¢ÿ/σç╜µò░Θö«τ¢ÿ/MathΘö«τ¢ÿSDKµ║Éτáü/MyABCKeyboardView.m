//
//  MyABCKeyboardView.m
//  LSKeyboard
//
//  Created by MyMac on 2018/7/30.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "MyABCKeyboardView.h"

#import "UIButton+BackgroundColor.h"
#import "UITextField+Cursor.h"


#define Formula_W ([UIScreen mainScreen].bounds.size.width/7.5)
#define Number_W ([UIScreen mainScreen].bounds.size.width/5.77)
#define Color(a,b,c,d) [UIColor colorWithRed:a/255.0 green:b/255.0 blue:c/255.0 alpha:d]
#define ColorSame(a) [UIColor colorWithRed:a/255.0 green:a/255.0 blue:a/255.0 alpha:1]
#define View_H(a)  (a.bounds.size.height)
#define View_W(a)  (a.bounds.size.width)

#define MAXX(a) (CGRectGetMaxX(a.frame))
#define MAXY(a) (CGRectGetMaxY(a.frame))
#define Line(x,y,w,h) [[UIView alloc]initWithFrame:CGRectMake(x, y,w,h)]
#define IntToString(a) ([NSString stringWithFormat:@"%d",a])

#define X(a) (a.frame.origin.x)
#define Y(a) (a.frame.origin.y)

#define W ([UIScreen mainScreen].bounds.size.width)
#define H ([UIScreen mainScreen].bounds.size.height)

#define buttton_W ((W-buttton_S)/10- buttton_S)
#define buttton_H ((self.bounds.size.height-buttton_H_S*4-bottomHeight-5)/3)
#define bottomHeight (self.bounds.size.height-([UIScreen mainScreen].bounds.size.width/7.5)*4-5-10)
#define buttton_S 5
#define buttton_H_S 10
#define buttton_Y_J 5.f


@interface MyABCKeyboardView ()

@property (nonatomic,strong) UIView * fuleiView;
@property (nonatomic,strong) UIView * view_left_two;
@property (nonatomic,strong) UIView * view_right_one;
@property (nonatomic,strong) NSArray * arrayData;
@property (nonatomic, assign) BOOL isDaXie;


@end

@implementation MyABCKeyboardView

-(instancetype)init
{
    if (self = [super init]) {
        [self createFuLei];
        [self setUI1];
        [self setUI2];
        [self setUI3];
        [self setUI4];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self createFuLei];
        [self setUI1];
        [self setUI2];
        [self setUI3];
        [self setUI4];
    }
    return self;
}
- (void)createFuLei {
    NSLog(@"%f",bottomHeight);
    [self.fuleiView removeFromSuperview];
    self.fuleiView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, W, self.bounds.size.height)];
    self.fuleiView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.fuleiView];
}
-(void)setUI1
{
    NSArray * arr_1 = nil;
    if (self.isDaXie) {
         arr_1 = @[@"Q",@"W",@"E",@"R",@"T",@"Y",@"U",@"I",@"O",@"P"];
    } else {
        arr_1 = @[@"q",@"w",@"e",@"r",@"t",@"y",@"u",@"i",@"o",@"p"];
    }
    
    
    
    UIView *fristView = [[UIView alloc]initWithFrame:CGRectMake(buttton_S, buttton_H_S, W-buttton_S, buttton_H)];
    fristView.backgroundColor= [UIColor clearColor];
    [self.fuleiView addSubview:fristView];
    for (NSInteger i=0; i<arr_1.count; i++) {
        UIView *dangeZiMuButtonView = [[UIView alloc]initWithFrame:CGRectMake((W-buttton_S)/10*i, 0, (W-buttton_S)/10, buttton_H)];
        dangeZiMuButtonView.backgroundColor = [UIColor clearColor];
        [fristView addSubview:dangeZiMuButtonView];
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, buttton_W, buttton_H);
        button.tag = i;
        [self setButtonShuXing:button];
        button.titleLabel.font = [UIFont systemFontOfSize:20];
        [button setTitle:arr_1[i] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
        [dangeZiMuButtonView addSubview:button];
    }
}

- (void)setUI2 {
    
   
    NSArray * arr_2 = nil;
    if (self.isDaXie) {
        arr_2 = @[@"A",@"S",@"D",@"F",@"G",@"H",@"J",@"K",@"L"];
    } else {
         arr_2 = @[@"a",@"s",@"d",@"f",@"g",@"h",@"j",@"k",@"l"];
    }
    
    
    UIView *secendView = [[UIView alloc]initWithFrame:CGRectMake(W*0.5-((W-buttton_S)/10*arr_2.count)*0.5+buttton_S*0.5, buttton_H_S+buttton_H+buttton_H_S, (W-buttton_S)/10*arr_2.count, buttton_H)];
    secendView.backgroundColor= [UIColor clearColor];
    [self.fuleiView addSubview:secendView];
    for (NSInteger i=0; i<arr_2.count; i++) {
        
        UIView *dangeZiMuButtonView = [[UIView alloc]initWithFrame:CGRectMake((W-buttton_S)/10*i, 0, (W-buttton_S)/10, buttton_H)];
        dangeZiMuButtonView.backgroundColor = [UIColor clearColor];
        [secendView addSubview:dangeZiMuButtonView];
        
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, buttton_W, buttton_H);
        button.tag = i+10;
        button.titleLabel.font = [UIFont systemFontOfSize:20];
       [self setButtonShuXing:button];
        [button setTitle:arr_2[i] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
        [dangeZiMuButtonView addSubview:button];
    }
    
    
}

- (void)setUI3 {
    
    NSArray * arr_3 = nil;
    if (self.isDaXie) {
        arr_3 = @[@"Z",@"X",@"C",@"V",@"B",@"N",@"M"];
    } else {
        arr_3 = @[@"z",@"x",@"c",@"v",@"b",@"n",@"m"];
    }
    UIView *secendView = [[UIView alloc]initWithFrame:CGRectMake(W*0.5-((W-buttton_S)/10*arr_3.count)*0.5+2.5, buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S, (W-5)/10*arr_3.count, buttton_H)];
    secendView.backgroundColor= [UIColor clearColor];
    [self.fuleiView addSubview:secendView];
    for (NSInteger i=0; i<arr_3.count; i++) {
        
        UIView *dangeZiMuButtonView = [[UIView alloc]initWithFrame:CGRectMake((W-buttton_S)/10*i, 0, (W-buttton_S)/10, buttton_H)];
        dangeZiMuButtonView.backgroundColor = [UIColor clearColor];
        [secendView addSubview:dangeZiMuButtonView];
        
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, buttton_W, buttton_H);
        button.tag = i+19;
        [self setButtonShuXing:button];
        button.titleLabel.font = [UIFont systemFontOfSize:20];
        [button setTitle:arr_3[i] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
        [dangeZiMuButtonView addSubview:button];
    }
    
    
    UIButton *daXiaoXiebutton = [[UIButton alloc]initWithFrame:CGRectMake(buttton_S, buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S, 45, buttton_H)];
    daXiaoXiebutton.tag = 26;
    [self setButtonShuXing:daXiaoXiebutton];
    if (self.isDaXie) {
        [daXiaoXiebutton setImage:[UIImage imageNamed:@"切换大写"] forState:UIControlStateNormal];
    } else {
        [daXiaoXiebutton setImage:[UIImage imageNamed:@"切换小写"] forState:UIControlStateNormal];
    }
    [daXiaoXiebutton addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
    [self.fuleiView addSubview:daXiaoXiebutton];
    
    
    UIButton *tuigebutton = [[UIButton alloc]initWithFrame:CGRectMake(W- buttton_S-45, buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S, 45, buttton_H)];
    tuigebutton.tag = 27;
    [self setButtonShuXing:tuigebutton];
    [tuigebutton setImage:[UIImage imageNamed:@"退格"] forState:UIControlStateNormal];
    [tuigebutton addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
    [self.fuleiView addSubview:tuigebutton];
    
    
}


- (void)setUI4 {
    
    UIButton *fanhuibutton = [[UIButton alloc]initWithFrame:CGRectMake(buttton_S, buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S, 70, bottomHeight)];
    fanhuibutton.tag = 28;
    [fanhuibutton setBackgroundColor:Color(95, 200, 153,1) forState:UIControlStateNormal];
    fanhuibutton.layer.cornerRadius = buttton_Y_J;
    fanhuibutton.layer.masksToBounds = YES;
    [fanhuibutton setTitle:@"返回" forState:UIControlStateNormal];
    fanhuibutton.titleLabel.font = [UIFont systemFontOfSize:15];
    [fanhuibutton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [fanhuibutton addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
    [self.fuleiView addSubview:fanhuibutton];
    
    
    UIButton *qundingbutton = [[UIButton alloc]initWithFrame:CGRectMake(W- buttton_S-70, buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S, 70, bottomHeight)];
    qundingbutton.tag = 29;
    qundingbutton.layer.cornerRadius = buttton_Y_J;
    qundingbutton.layer.masksToBounds = YES;
    qundingbutton.titleLabel.font = [UIFont systemFontOfSize:15];
    [qundingbutton setBackgroundColor:Color(201,204,207,1) forState:UIControlStateNormal];
    [qundingbutton setBackgroundColor:Color(95, 200, 153,1) forState:UIControlStateSelected];
    [qundingbutton setTitleColor:Color(138, 140, 142, 1) forState:UIControlStateNormal];
    [qundingbutton setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    [qundingbutton addTarget:self action:@selector(noHighed:) forControlEvents:UIControlEventAllTouchEvents];
    [qundingbutton setTitleColor:Color(138, 140, 142, 1) forState:UIControlStateNormal];
    [qundingbutton setTitle:@"确定" forState:UIControlStateNormal];
    [qundingbutton addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
    [self.fuleiView addSubview:qundingbutton];
    
    
    
    UIButton *fuHaobutton = [[UIButton alloc]initWithFrame:CGRectMake(fanhuibutton.frame.origin.x+fanhuibutton.frame.size.width+buttton_S, buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S, 55, bottomHeight)];
    fuHaobutton.tag = 30;
    [fuHaobutton setBackgroundColor:[UIColor colorWithRed:205.0/255.0 green:205.0/255.0 blue:205.0/255.0 alpha:1] forState:UIControlStateNormal];
    [fuHaobutton setBackgroundColor:[UIColor colorWithRed:205.0/255.0 green:205.0/255.0 blue:205.0/255.0 alpha:1] forState:UIControlStateHighlighted];
    fuHaobutton.layer.cornerRadius = buttton_Y_J;
    fuHaobutton.layer.masksToBounds = YES;
    fuHaobutton.titleLabel.font = [UIFont systemFontOfSize:15];
    [fuHaobutton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [fuHaobutton setTitle:@"符" forState:UIControlStateNormal];
    [fuHaobutton addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
    [self.fuleiView addSubview:fuHaobutton];
    
    
    UIView *jiaAndJianAndDengView = [[UIView alloc]initWithFrame:CGRectMake(fuHaobutton.frame.origin.x+fuHaobutton.frame.size.width+buttton_S, buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S+buttton_H+buttton_H_S, W-(fuHaobutton.frame.origin.x+fuHaobutton.frame.size.width+buttton_S)-70-10, bottomHeight)];
    jiaAndJianAndDengView.backgroundColor = [UIColor colorWithRed:205.0/255.0 green:205.0/255.0 blue:205.0/255.0 alpha:1];
    jiaAndJianAndDengView.layer.cornerRadius = buttton_Y_J;
    jiaAndJianAndDengView.layer.masksToBounds = YES;
    [self.fuleiView addSubview:jiaAndJianAndDengView];
    
    NSArray *fuhaoArr = @[@"+",@"-",@"="];
    for (NSInteger i=0; i<fuhaoArr.count; i++) {
        
        UIButton *fuhaoButton4 = [UIButton buttonWithType:UIButtonTypeCustom];
        fuhaoButton4.frame = CGRectMake(i*(W-(fuHaobutton.frame.origin.x+fuHaobutton.frame.size.width+buttton_S)-70-10)/3, 0, (W-(fuHaobutton.frame.origin.x+fuHaobutton.frame.size.width+buttton_S)-70-10)/3, bottomHeight);
        fuhaoButton4.tag = i+31;
        fuhaoButton4.titleLabel.font = [UIFont systemFontOfSize:22];
        [fuhaoButton4 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [fuhaoButton4 setTitle:fuhaoArr[i] forState:UIControlStateNormal];
        [fuhaoButton4 addTarget:self action:@selector(button1Action:) forControlEvents:UIControlEventTouchUpInside];
        [jiaAndJianAndDengView addSubview:fuhaoButton4];
        
        if (i != 2) {
            UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(fuhaoButton4.frame.origin.x+fuhaoButton4.frame.size.width, 10, 0.5, 30)];
            lineView.backgroundColor = [UIColor grayColor];
            [jiaAndJianAndDengView addSubview:lineView];
        }
        
        
    }
    
    
}
-(void)noHighed:(UIButton*)button
{
    button.highlighted = NO;
}

- (void)button1Action:(UIButton *)button {
    NSLog(@"%ld",button.tag);
    
    
    if (button.tag == 26) {//大小写
        self.isDaXie = !self.isDaXie;
        [self createFuLei];
        [self setUI1];
        [self setUI2];
        [self setUI3];
        [self setUI4];
    } else if (button.tag == 27) {//退格
        if ([self.delegate respondsToSelector:@selector(deleteButtonAction)]) {
            [self.delegate deleteButtonAction];
        }
    } else if (button.tag == 28) {//返回
        
        [self removeFromSuperview];
    } else if (button.tag == 29) {//确定
        
        if ([self.delegate respondsToSelector:@selector(sureButtonAction)]) {
            [self.delegate sureButtonAction];
        }
        [self removeFromSuperview];
    }else if (button.tag == 30) {//符
        
        if ([self.delegate respondsToSelector:@selector(detailButtonAction)]) {
            [self.delegate detailButtonAction];
        }
        [self removeFromSuperview];
    }else if (button.tag >= 31) {//符
        NSArray *fuhaoArr = @[@"+",@"-",@"="];
        if ([self.delegate respondsToSelector:@selector(enterABCMessage:)]) {
            [self.delegate enterABCMessage:fuhaoArr[button.tag-31]];
        }
        
    } else {
    
        if ([self.delegate respondsToSelector:@selector(enterABCMessage:)]) {
            [self.delegate enterABCMessage:button.titleLabel.text];
        }
       
    }
}


- (void)setButtonShuXing:(UIButton *)button{
    [button setBackgroundColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button setBackgroundColor:Color(172,173,177,1) forState:UIControlStateHighlighted];
    button.layer.cornerRadius = buttton_Y_J;
    button.layer.masksToBounds = YES;
    button.titleLabel.font = [UIFont systemFontOfSize:20];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}



@end
