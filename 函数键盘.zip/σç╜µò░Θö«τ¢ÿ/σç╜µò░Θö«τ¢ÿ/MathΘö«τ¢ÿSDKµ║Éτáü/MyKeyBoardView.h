//
//  MyKeyBoardView.h
//  LSKeyboard
//
//  Created by apple on 2018/7/28.
//  Copyright © 2018年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MyKeyBoardViewDelegate <NSObject>
-(void)enterMessage:(NSString*)string;
-(void)enterMothed:(NSString *)string;
-(void)sureMothed;
@end

@interface MyKeyBoardView : UIView
-(void)setUI;

@property (nonatomic,weak)id <MyKeyBoardViewDelegate> delegate;

@end
