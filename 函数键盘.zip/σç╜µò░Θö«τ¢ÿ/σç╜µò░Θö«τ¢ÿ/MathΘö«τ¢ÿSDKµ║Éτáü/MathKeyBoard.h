//
//  MathKeyBoard.h
//  LSKeyboard
//
//  Created by apple on 2018/7/31.
//  Copyright © 2018年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MathKeyBoard : UIView

-(void)showKey:(BOOL)isBool;


@end
