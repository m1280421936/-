//
//  ViewController.m
//  函数键盘
//
//  Created by MyMac on 2019/1/3.
//  Copyright © 2019年 zhangjian. All rights reserved.
//

#import "ViewController.h"

#import "MathKeyBoard.h"


@interface ViewController ()

@property (nonatomic, strong) MathKeyBoard *mathKeyBord;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UIButton *sureButton = [[UIButton alloc]initWithFrame:CGRectMake(50, 70, 70, 40)];
    [sureButton setTitle:@"展示" forState:UIControlStateNormal];
    sureButton.backgroundColor =[ UIColor redColor];
    [sureButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [sureButton addTarget:self action:@selector(sureButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sureButton];
    
    
    UIButton *cancelButton = [[UIButton alloc]initWithFrame:CGRectMake(self.view.bounds.size.width-50-70, 70, 70, 40)];
    [cancelButton setTitle:@"隐藏" forState:UIControlStateNormal];
    cancelButton.backgroundColor =[ UIColor redColor];
    [cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(cancelButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:cancelButton];
    
    [self cancelButtonAction];
}

- (MathKeyBoard *)mathKeyBord {
    if (!_mathKeyBord) {
        //246
        _mathKeyBord = [[MathKeyBoard alloc]initWithFrame:CGRectMake(0, 100, self.view.bounds.size.width, self.view.bounds.size.height - 100)];
    }
    return _mathKeyBord;
}
- (void)sureButtonAction {
    [self.view addSubview:self.mathKeyBord];
    [self.mathKeyBord showKey:YES];
}

- (void)cancelButtonAction {
    [self.mathKeyBord showKey:NO];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
